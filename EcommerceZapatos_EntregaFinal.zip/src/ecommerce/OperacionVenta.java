
package ecommerce;
@FunctionalInterface
public interface OperacionVenta {
    double calcular(double precio,int cantidad);
}
