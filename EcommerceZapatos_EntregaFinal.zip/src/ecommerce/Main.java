
package ecommerce;
import java.util.*; import java.time.*; import java.util.stream.*;
public class Main{
 public static void mostrar(List<Producto> p,int i){
   if(i>=p.size()) return;
   System.out.println(p.get(i).getId()+"-"+p.get(i).getNombre()+" Stock:"+p.get(i).getCantidad());
   mostrar(p,i+1);
 }
 public static void main(String[] args){
   Scanner sc=new Scanner(System.in);
   List<Producto> productos=new ArrayList<>();
   List<Venta> ventas=new ArrayList<>();
   productos.add(new Producto(1,"Nike Air",350000,10,"Deportivo"));
   productos.add(new Producto(2,"Adidas Run",280000,8,"Running"));
   int op;
   do{
    System.out.println("\n1 Venta 2 Inventario 3 TotalVentas 4 MasVendido 0 Salir");
    op=sc.nextInt();
    switch(op){
      case 1:
       System.out.print("ID:"); int id=sc.nextInt();
       System.out.print("Cant:"); int c=sc.nextInt();
       productos.stream().filter(x->x.getId()==id).findFirst().ifPresent(x->{
         if(x.getCantidad()>=c){
           OperacionVenta ov=(p,q)->p*q;
           ventas.add(new Venta("V"+(ventas.size()+1),id,LocalDate.now(),c,ov.calcular(x.getPrecio(),c)));
           x.setCantidad(x.getCantidad()-c);
           System.out.println("Venta registrada");
         }
       });
       break;
      case 2: mostrar(productos,0); break;
      case 3: System.out.println("Total:"+ventas.stream().mapToDouble(Venta::getTotal).sum()); break;
      case 4:
       ventas.stream().collect(Collectors.groupingBy(Venta::getIdProducto,Collectors.summingInt(Venta::getCantidad)))
       .entrySet().stream().max(Map.Entry.comparingByValue())
       .ifPresent(e->productos.stream().filter(p->p.getId()==e.getKey()).findFirst()
       .ifPresent(p->System.out.println(p.getNombre()+" $"+p.getPrecio())));
    }
   }while(op!=0);
 }
}
