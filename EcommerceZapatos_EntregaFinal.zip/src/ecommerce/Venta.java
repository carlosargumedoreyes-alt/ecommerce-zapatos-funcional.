
package ecommerce;
import java.time.LocalDate;
public class Venta {
    private String codigo; private int idProducto; private LocalDate fecha;
    private int cantidad; private double total;
    public Venta(String codigo,int idProducto,LocalDate fecha,int cantidad,double total){
        this.codigo=codigo; this.idProducto=idProducto; this.fecha=fecha; this.cantidad=cantidad; this.total=total;
    }
    public String getCodigo(){return codigo;}
    public int getIdProducto(){return idProducto;}
    public LocalDate getFecha(){return fecha;}
    public int getCantidad(){return cantidad;}
    public double getTotal(){return total;}
}
