package model;
import java.time.LocalDate;
public class Venta {
    private int codigo,idProducto,cantidad; private LocalDate fecha; private double total;
    public Venta(int codigo,int idProducto,LocalDate fecha,int cantidad,double total){
        this.codigo=codigo;this.idProducto=idProducto;this.fecha=fecha;this.cantidad=cantidad;this.total=total;
    }
    public int getCodigo(){return codigo;} public int getIdProducto(){return idProducto;}
    public LocalDate getFecha(){return fecha;} public int getCantidad(){return cantidad;}
    public double getTotal(){return total;}
}