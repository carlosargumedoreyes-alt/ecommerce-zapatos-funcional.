package interfaces;
import model.Producto;
@FunctionalInterface
public interface OperacionProducto { void ejecutar(Producto producto); }