package service;
public class ReporteService{
 public void mostrar(){ System.out.println("Reportes con Streams"); }
}