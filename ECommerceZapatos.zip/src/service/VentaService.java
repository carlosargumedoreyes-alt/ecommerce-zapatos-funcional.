package service;
import model.*; import java.util.*; import java.time.LocalDate;
public class VentaService{
 private final List<Venta> ventas=new ArrayList<>(); private final InventarioService inv;
 public VentaService(InventarioService inv){this.inv=inv;}
 public void registrarVenta(int codigo,int idProducto,int cantidad){
   inv.buscarProducto(idProducto).ifPresent(p->{
     if(p.getCantidad()>=cantidad){
       p.setCantidad(p.getCantidad()-cantidad);
       ventas.add(new Venta(codigo,idProducto,LocalDate.now(),cantidad,p.getPrecio()*cantidad));
     }
   });
 }
 public List<Venta> obtenerVentas(){return ventas;}
}