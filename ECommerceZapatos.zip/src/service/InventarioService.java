package service;
import model.Producto;
import java.util.*;
public class InventarioService{
 private final List<Producto> productos=new ArrayList<>();
 public void agregarProducto(Producto p){productos.add(p);}
 public List<Producto> obtenerProductos(){return productos;}
 public Optional<Producto> buscarProducto(int id){
   return productos.stream().filter(p->p.getId()==id).findFirst();
 }
}