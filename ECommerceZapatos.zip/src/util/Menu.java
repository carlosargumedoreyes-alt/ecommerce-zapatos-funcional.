package util;
import java.util.Scanner;
public class Menu{
 public void iniciar(){
   Scanner sc=new Scanner(System.in);
   System.out.println("Proyecto ECommerceZapatos listo.");
 }
}